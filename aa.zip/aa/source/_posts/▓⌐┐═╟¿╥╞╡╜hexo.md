最近，我把[博客](https://stzo.cn)从wordpress转向hexo,主要是因为hexo拥有wordpress无法匹敌的轻量性，而且纯静态博客，性能更好。其实文章写起来都差不多，都是markdown.（还有我感觉hexo的indigo主题比较好看）
首先，安装hexo环境，可以去[hexo官网](https://hexo.io/)，里面有详细的教程。
![](https://shop.io.mi-img.com/app/shop/img?id=shop_0daa73245a54c404aa0ec843e1e3b9b3.png)
打开git工具，输入：
```
hexo g
```
来生成静态文件，在public目录底下，直接把public目录底下的文件上传到服务器就好了。
当然，hexo也提供本地测试：
```
hexo server
```
然后访问[http://localhost:4000](http://localhost:4000)就可以看到你的博客了。
插件什么的，大家可以自由添加，实现评论，统计等等。
放张成品图：
![](https://shop.io.mi-img.com/app/shop/img?id=shop_6a2de3876da9bb6759de72e08567a06f.png)
漂亮吧！
至于indigo主题不自带友情链接的问题。。。
我直接把tags页面改成了友情链接页面emmm。。。