最近闲的无聊，建了一个tg api的代理，实现在中国大陆访问tg api，实现bot功能。
速度不错，用的cf workers，每天10万次请求，理智使用。
网址：[https://ss.stzo.cn](https://ss.stzo.cn)
调用方法：把api.telegram.org替换为ss.stzo.cn即可